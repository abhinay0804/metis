import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Search, 
  Eye, 
  Download, 
  Filter,
  Calendar,
  Shield,
  BarChart3,
  FileText
} from "lucide-react";

interface HistoryTableProps {
  filter?: 'mask' | 'analysis';
}

const HistoryTable = ({ filter }: HistoryTableProps) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRecord, setSelectedRecord] = useState<any>(null);

  // Mock data - in real app this would come from API
  const historyData = [
    {
      id: 1,
      fileName: "customer_data.csv",
      type: "mask",
      status: "completed",
      date: "2024-01-20",
      time: "14:30:25",
      maskedFields: ["email", "phone", "ssn"],
      maskedData: {
        email: "***@***.com",
        phone: "***-***-1234", 
        ssn: "***-**-1234"
      },
      confidence: 98
    },
    {
      id: 2,
      fileName: "transaction_log.xlsx",
      type: "analysis",
      status: "completed", 
      date: "2024-01-20",
      time: "12:15:10",
      dataQuality: 87,
      riskLevel: "Medium",
      sensitiveFields: 8,
      compliance: ["PCI-DSS", "GDPR"]
    },
    {
      id: 3,
      fileName: "employee_records.json",
      type: "mask",
      status: "completed",
      date: "2024-01-19",
      time: "16:45:33",
      maskedFields: ["email", "salary", "address"],
      maskedData: {
        email: "***@company.com",
        salary: "$**,***",
        address: "*** *** Street"
      },
      confidence: 95
    },
    {
      id: 4,
      fileName: "audit_trail.csv",
      type: "analysis",
      status: "failed",
      date: "2024-01-19",
      time: "10:20:15",
      error: "File format not supported"
    },
    {
      id: 5,
      fileName: "payment_data.xlsx",
      type: "mask",
      status: "processing",
      date: "2024-01-18",
      time: "18:10:05",
      progress: 75
    }
  ];

  const filteredData = historyData
    .filter(item => !filter || item.type === filter)
    .filter(item => 
      item.fileName.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge variant="default" className="bg-success">Completed</Badge>;
      case 'processing':
        return <Badge variant="secondary">Processing</Badge>;
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getTypeBadge = (type: string) => {
    if (type === 'mask') {
      return (
        <Badge variant="secondary" className="bg-data-mask/10 text-data-mask border-data-mask/20">
          <Shield className="h-3 w-3 mr-1" />
          Masking
        </Badge>
      );
    }
    return (
      <Badge variant="secondary" className="bg-data-analysis/10 text-data-analysis border-data-analysis/20">
        <BarChart3 className="h-3 w-3 mr-1" />
        Analysis
      </Badge>
    );
  };

  const MaskedDataDialog = ({ record }: { record: any }) => (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">
          <Eye className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Masked Data Preview</DialogTitle>
          <DialogDescription>
            {record.fileName} - Processed on {record.date}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground">Confidence:</span>
              <p className="font-semibold">{record.confidence}%</p>
            </div>
            <div>
              <span className="text-muted-foreground">Fields Masked:</span>
              <p className="font-semibold">{record.maskedFields?.length || 0}</p>
            </div>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-medium text-sm">Masked Values:</h4>
            {record.maskedData && Object.entries(record.maskedData).map(([field, value]) => (
              <div key={field} className="flex justify-between items-center p-2 bg-muted rounded">
                <span className="text-sm capitalize">{field}</span>
                <Badge variant="secondary" className="font-mono text-xs">
                  {value as string}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );

  const AnalysisDataDialog = ({ record }: { record: any }) => (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">
          <Eye className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Analysis Results</DialogTitle>
          <DialogDescription>
            {record.fileName} - Analyzed on {record.date}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-muted rounded-lg">
              <p className="text-2xl font-bold text-data-analysis">{record.dataQuality}%</p>
              <p className="text-xs text-muted-foreground">Data Quality</p>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <p className="text-2xl font-bold text-warning">{record.riskLevel}</p>
              <p className="text-xs text-muted-foreground">Risk Level</p>
            </div>
          </div>
          
          <div>
            <h4 className="font-medium text-sm mb-2">Sensitive Fields Found:</h4>
            <p className="text-2xl font-bold text-destructive">{record.sensitiveFields}</p>
          </div>

          <div>
            <h4 className="font-medium text-sm mb-2">Compliance Standards:</h4>
            <div className="flex flex-wrap gap-1">
              {record.compliance?.map((standard: string, index: number) => (
                <Badge key={index} variant="outline">{standard}</Badge>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Processing History
              {filter && (
                <Badge variant="outline" className="ml-2">
                  {filter === 'mask' ? 'Masking Only' : 'Analysis Only'}
                </Badge>
              )}
            </CardTitle>
            <CardDescription>
              Track all your data processing activities
            </CardDescription>
          </div>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Search and Filters */}
        <div className="flex items-center gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search files..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button variant="outline" size="sm">
            <Calendar className="h-4 w-4 mr-2" />
            Date Range
          </Button>
        </div>

        {/* Table */}
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">#</TableHead>
                <TableHead>File Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Time</TableHead>
                <TableHead className="text-center">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    No records found
                  </TableCell>
                </TableRow>
              ) : (
                filteredData.map((record, index) => (
                  <TableRow key={record.id}>
                    <TableCell className="font-medium">{index + 1}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        {record.fileName}
                      </div>
                    </TableCell>
                    <TableCell>{getTypeBadge(record.type)}</TableCell>
                    <TableCell>{getStatusBadge(record.status)}</TableCell>
                    <TableCell>{record.date}</TableCell>
                    <TableCell>{record.time}</TableCell>
                    <TableCell>
                      <div className="flex items-center justify-center gap-1">
                        {record.status === 'completed' && (
                          <>
                            {record.type === 'mask' ? (
                              <MaskedDataDialog record={record} />
                            ) : (
                              <AnalysisDataDialog record={record} />
                            )}
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4" />
                            </Button>
                          </>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};

export default HistoryTable;